
 const checkNum = document.querySelector('.check')
 const resetButton = document.querySelector('.reset')
 let guessing = document.querySelector('.img')
 let historyH = document.querySelector('.historyH')

 let msg=document.querySelector('.msg')
 let box = document.querySelector('.box')
 const userNum = document.querySelector('.userInput')
 let currentS = document.querySelector('.currentS')
 let historyS = document.querySelector('.historyS')
 const historySame = document.querySelector('.historysame')
 let currentSx="";
 let secretNum=Math.trunc(Math.random() * 100 + 1);
 console.log(secretNum);
 arrayHistory=[];
 $('p').css('color','red')
 $('p').css('font-family','fantasy')
 currentSx=currentS.textContent=10;

checkNum.addEventListener('click',function () {
arrayHistory.push(userNum.value)


    historyS.textContent=`Previous Guesses : ${arrayHistory}`
    let numc=false;
    for(i=0;i<arrayHistory.length;i++){
    for(j=i+1;j<arrayHistory.length;j++){
     if(arrayHistory[i]==arrayHistory[j]){
        
     numc=true;
     }}}
 
    if (numc==true) {
        console.log(currentSx)
        
       currentSx=currentS.textContent;
       console.log(currentSx)
      
       
      
    msg.textContent='!You have tried this number, Please try again!'
    currentSx=currentSx+1;

    }else if (userNum.value == secretNum&&currentSx!=0) {
    document.body.style.backgroundColor="pink"
    msg.textContent = "You Got the Secret Number! "+secretNum+" Congratulations!!! ";
     $(box).css('background-color','rgb(224, 224, 114)')
     $(box).css('height','600px')
     userNum.value="";
    
     $('input').attr('placeholder','!!!  Winner  !!!')
     $('input').css('font-weight','bold')
     $('img').attr('src','source.gif')
       
    } 
    else if(currentSx<1){
        msg.textContent="Sorry You Lost the Game";
        $('img').attr('src','giphy.gif')
    }
    
    
    else if (userNum.value > secretNum) {
        $('img').attr('src','alert.gif')
        msg.textContent = 'Too High, Be Carefull Don`t Fall';
            console.log(currentSx)
            currentSx=currentSx-1;
            currentS.textContent=currentSx;
           
     } 
     
     
     else if (userNum.value < secretNum&&userNum.value >=1) {
        $('img').attr('src','alert.gif')
      
       currentSx=currentSx-1;
       currentS.textContent=currentSx;
         msg.textContent = 'Too Low Think Big';
        
        
     } 
     else if(userNum.value!=Number||userNum.value=='0'){
      
        msg.textContent = 'No Input or Invalid Value'
       

     } else if(currentSx<1){
         msg.textContent="sorry u lost the game";
         
     }
     else if(currentSx>historyH){
         historyH.textContent=currentSx;
     }
console.log(arrayHistory)
console.log(userNum.value)



        })


resetButton.addEventListener('click',function () {
    console.log(currentSx)
    historyH.textContent=`High score History  `+currentSx;
    console.log(historyH.textContent)

      
    
  
msg.textContent="No input";
document.getElementById('input').value='';

currentS.textContent=10;
currentSx=currentS.textContent;
historyS.textContent="";


document.body.style.backgroundColor="lightskyblue"
let secretNumnew=Math.trunc(Math.random() * 100 + 1);
secretNum=secretNumnew;
console.log(secretNumnew)
userNum.value="";
arrayHistory=[];
$('input').attr('placeholder','Please enter number')
$(box).css('background-color','lightskyblue')

  

})
